<?php

?>

<form action="formulaire2-traitement.php" method="post">
    <div><label for="ville">ville:</label></div>
    <div><input type="text" name="ville" id="name"></div>
    <div><label for="cp">Code postal:</label></div>
    <div><input type="text" name="cp" id="cp"></div>
    <div><label for="adresse">Adresse:</label></div>
    <div><textarea name="adresse" id="adresse"></textarea></div>
    <hr>
    <div><button type="submit">envoyer</button></div>

</form>
