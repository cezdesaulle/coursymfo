<?php

namespace ContainerLVWv69A;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder821ba = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializera15b6 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties132c8 = [
        
    ];

    public function getConnection()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'getConnection', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'getMetadataFactory', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'getExpressionBuilder', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'beginTransaction', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->beginTransaction();
    }

    public function getCache()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'getCache', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->getCache();
    }

    public function transactional($func)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'transactional', array('func' => $func), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->transactional($func);
    }

    public function commit()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'commit', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->commit();
    }

    public function rollback()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'rollback', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'getClassMetadata', array('className' => $className), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'createQuery', array('dql' => $dql), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'createNamedQuery', array('name' => $name), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'createQueryBuilder', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'flush', array('entity' => $entity), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'clear', array('entityName' => $entityName), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->clear($entityName);
    }

    public function close()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'close', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->close();
    }

    public function persist($entity)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'persist', array('entity' => $entity), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'remove', array('entity' => $entity), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'refresh', array('entity' => $entity), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'detach', array('entity' => $entity), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'merge', array('entity' => $entity), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'getRepository', array('entityName' => $entityName), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'contains', array('entity' => $entity), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'getEventManager', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'getConfiguration', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'isOpen', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'getUnitOfWork', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'getProxyFactory', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'initializeObject', array('obj' => $obj), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'getFilters', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'isFiltersStateClean', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'hasFilters', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return $this->valueHolder821ba->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializera15b6 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder821ba) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder821ba = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder821ba->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, '__get', ['name' => $name], $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        if (isset(self::$publicProperties132c8[$name])) {
            return $this->valueHolder821ba->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder821ba;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder821ba;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, '__set', array('name' => $name, 'value' => $value), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder821ba;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder821ba;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, '__isset', array('name' => $name), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder821ba;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder821ba;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, '__unset', array('name' => $name), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder821ba;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder821ba;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, '__clone', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        $this->valueHolder821ba = clone $this->valueHolder821ba;
    }

    public function __sleep()
    {
        $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, '__sleep', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;

        return array('valueHolder821ba');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializera15b6 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializera15b6;
    }

    public function initializeProxy() : bool
    {
        return $this->initializera15b6 && ($this->initializera15b6->__invoke($valueHolder821ba, $this, 'initializeProxy', array(), $this->initializera15b6) || 1) && $this->valueHolder821ba = $valueHolder821ba;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder821ba;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder821ba;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
