<?php
echo "<p>Ceci est le fichier d'inclusion.</p>";

$inclusion="Cette variable est déclarée dans le fichier d'inclusion.";