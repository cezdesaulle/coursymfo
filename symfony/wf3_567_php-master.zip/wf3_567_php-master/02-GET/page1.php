
<h1>Nos produits</h1>

<a href="page2.php?article=jean&couleur=bleu&prix=10">Jean bleu</a>
<a href="page2.php?article=pull&couleur=blanc&prix=20">Pull blanc</a>
<a href="page2.php?article=robe&couleur=rouge&prix=30">Robe rouge</a>
